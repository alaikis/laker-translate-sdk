import typescript from '@rollup/plugin-typescript';

export default {
  input: 'translation-client.ts',
  // Keep dependencies external - host projects must install @bufbuild/* and @connectrpc/*
  // The generated code imports from @bufbuild/protobuf/codegenv2 which is a codegen-only module
  // that doesn't exist at runtime, but rollup will handle this at runtime
  external: [
    /^@bufbuild\//,
    /^@connectrpc\//,
    /^broadcast-channel/
  ],
  output: [
    {
      file: 'translation-client.cjs',
      format: 'cjs',
      sourcemap: true,
      exports: 'named'
    },
    {
      file: 'translation-client.js',
      format: 'esm',
      sourcemap: true,
      exports: 'named'
    }
  ],
  plugins: [typescript()]
};
