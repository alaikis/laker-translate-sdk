import typescript from '@rollup/plugin-typescript';

export default {
  input: 'translation-client.ts',
  external: [/^@bufbuild\//, /^@connectrpc\//, /^broadcast-channel/],
  output: [
    {
      file: 'translation-client.cjs',
      format: 'cjs',
      sourcemap: true,
      exports: 'named'
    },
    {
      file: 'translation-client.js',
      format: 'esm',
      sourcemap: true,
      exports: 'named'
    }
  ],
  plugins: [typescript()]
};
